from django.db import models



# Create your models here.
class tableFiliere(models.Model):
    nomFiliere= models.CharField(max_length=500)
    date_creation=models.DateField(auto_now=True)

    def __str__(self):
        return self.nomFiliere

