from django.urls import path
from filiere import views

urlpatterns=[
    path('addFil/',views.add_filiere,name="addFil"),
    path('listFil/', views.list_filiere, name="listFil"),
    path('delFil/<int:id>',views.delete_filiere,name='delFil'),
    path('<int:id>', views.update_filiere, name='updateFil'),
]