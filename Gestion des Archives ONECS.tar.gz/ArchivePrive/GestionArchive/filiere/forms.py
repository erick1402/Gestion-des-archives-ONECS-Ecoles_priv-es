from django.forms import widgets

from .models import tableFiliere
from django import forms
class filiereForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
            super(filiereForm,self).__init__(*args, **kwargs)
            self.fields['nomFiliere'].label= "Filière"

    class Meta:
         model= tableFiliere
         fields= ['nomFiliere']
         widgets={
             'nomFiliere':forms.TextInput(attrs={'class':'form-control','placeholder':'Sciences de gestion'})
         }