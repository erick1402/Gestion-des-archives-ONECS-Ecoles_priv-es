from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from .models import tableFiliere
from .forms import filiereForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
# Create your views here.
@login_required
def add_filiere(request):
    if request.method == 'POST':
        fm= filiereForm(request.POST)
        if fm.is_valid():
           nmFil= fm.cleaned_data['nomFiliere']
           reg= tableFiliere(nomFiliere=nmFil)
           reg.save()
           messages.success(request,"Filière ajoutée avec succès!")

           fm= filiereForm()
    else:
        fm= filiereForm()

    return render(request,'filiere/addFiliere.html',{'navbar':'addFil','form':fm})

@login_required
def list_filiere(request):
    fil=tableFiliere.objects.all()
    return render(request,'filiere/listFiliere.html',{'navbar':'listFil','file':fil})

@login_required
def delete_filiere(request, id):
    if request.method=='POST':
        filiere=tableFiliere.objects.get(pk=id)
        filiere.delete()
        messages.success(request,'Filière supprimée avec succès!')
        return HttpResponseRedirect('/filiere/listFil')

@login_required
def update_filiere(request, id):
    if request.method=='POST':
        fil= tableFiliere.objects.get(pk=id)
        fm= filiereForm(request.POST,instance=fil)
        if fm.is_valid():
            fm.save()
            messages.success(request,"Filière modifiée avec succès!")
            return HttpResponseRedirect('/filiere/listFil')
    else:
        fil= tableFiliere.objects.get(pk=id)
        fm= filiereForm(instance=fil)
        return render(request,'filiere/updateFiliere.html',{'form':fm})