from django.contrib import admin

# Register your models here.
from .models import tableEtudiant
# Register your models here.
@admin.register(tableEtudiant)
class etudiantAdmin(admin.ModelAdmin):
    list_display = ('nomEtu','dateNaiss','lieuNaiss','etablissement','filiere','anneAca','observation')
from django.contrib import admin

# Register your models here.
