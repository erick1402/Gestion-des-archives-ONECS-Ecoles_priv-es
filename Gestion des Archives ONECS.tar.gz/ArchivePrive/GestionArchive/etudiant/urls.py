from django.urls import path
from etudiant import views

urlpatterns=[
    path('listEtu/',views.list_etudiant,name='listEtu'),
    path('addEtu/' ,views.add_etudiant, name='addEtu'),
    path('delEtu/<int:id>',views.delete_etudiant,name='delEtu'),
    path('<int:id>',views.update_etudiant, name='updateEtu')
]