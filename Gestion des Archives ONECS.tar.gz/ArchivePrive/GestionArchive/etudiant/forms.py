from .models import tableEtudiant
from django import forms
class etudiantForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(etudiantForm, self).__init__(*args, **kwargs)
        self.fields['nomEtu'].label = "Nom et Prénom"
        self.fields['dateNaiss'].label = "Date de naissance"
        self.fields['lieuNaiss'].label = "Lieu de naissance"
        self.fields['etablissement'].label = "Etablissement"
        self.fields['filiere'].label="Filière"
        self.fields['anneAca'].label = "Année académique"
        self.fields['observation'].label = "Décision du jury"

    class Meta:
        model= tableEtudiant
        fields=['nomEtu','dateNaiss','lieuNaiss','etablissement','filiere','anneAca','observation']
        widgets={
            'nomEtu':forms.TextInput(attrs={'class':'form-control','placeholder':'John Smith'}),
            'dateNaiss':forms.DateInput(attrs={'class':'form-control','placeholder':'02/17/1999'}),
            'lieuNaiss':forms.TextInput(attrs={'class':'form-control','placeholder':'N\'djamena'}),
            'etablissement':forms.Select(attrs={'class':'form-control'}),
            'filiere':forms.Select(attrs={'class': 'form-control'}),
            'anneAca':forms.TextInput(attrs={'class':'form-control','placeholder':'2020-2021'}),
            'observation':forms.Select(attrs={'class':'form-control'}),
        }
