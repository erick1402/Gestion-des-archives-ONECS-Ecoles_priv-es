from django.db import models
from django.db.models import ForeignKey
from django.utils import timezone

from etablissement.models import tableEtablissement
from filiere.models import tableFiliere

# Create your models here.
valeur_observation=[
    ('admis','Admis'),
    ('ajourné','Ajourné')
]
class tableEtudiant(models.Model):
    nomEtu=models.CharField(max_length=200)
    dateNaiss= models.DateField(null=True)
    lieuNaiss= models.CharField(max_length=200)
    etablissement= ForeignKey(tableEtablissement,related_name="etablissement_pk",on_delete=models.SET_NULL,null=True)
    filiere= ForeignKey(tableFiliere, on_delete=models.SET_NULL,null=True)
    anneAca= models.CharField(max_length=100,null=True)
    observation= models.CharField(max_length=100, choices=valeur_observation,default='admis')
    dateEtu= models.DateField(auto_now=True, verbose_name='Date de création_étudiant')
    def __str__(self):
        return self.nomEtu


from django.db import models

# Create your models here.
