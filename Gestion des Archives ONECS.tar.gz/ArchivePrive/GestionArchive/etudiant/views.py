from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render

from .forms import etudiantForm
from .models import tableEtudiant
from django.contrib import messages
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required
def list_etudiant(request):
    return render(request, 'etudiant/listEtudiant.html', {'navbar': 'listEtu'})

@login_required
def add_etudiant(request):
    if request.method == 'POST':
        fm = etudiantForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['nomEtu']
            dt = fm.cleaned_data['dateNaiss']
            lieu = fm.cleaned_data['lieuNaiss']
            etab = fm.cleaned_data['etablissement']
            fil = fm.cleaned_data['filiere']
            an = fm.cleaned_data['anneAca']
            obs = fm.cleaned_data['observation']
            reg = tableEtudiant(nomEtu=nm, dateNaiss=dt, lieuNaiss=lieu, etablissement=etab, filiere=fil, anneAca=an,
                                observation=obs)
            reg.save()
            messages.success(request,'Etudiant ajouté avec succès!')
            fm = etudiantForm()
    else:
        fm = etudiantForm()

    return render(request, 'etudiant/addEtudiant.html', {'navbar': 'addEtu', 'form': fm})

@login_required
def list_etudiant(resquest):
    etud = tableEtudiant.objects.all()
    context = {
        'navbar':'listEtu',
        'etud': etud
    }
    return render(resquest, 'etudiant/listEtudiant.html', context)

@login_required
def delete_etudiant(request, id):
    if request.method=='POST':
          etudiant= tableEtudiant.objects.get(pk=id)
          etudiant.delete()
          messages.success(request,'Etudiant supprimé avec succès!')
          return HttpResponseRedirect('/etudiant/listEtu')

@login_required
def update_etudiant(request, id):
    if request.method=='POST':
        etudiant=tableEtudiant.objects.get(pk=id)
        fm= etudiantForm(request.POST,instance=etudiant)
        if fm.is_valid():
            fm.save()
            messages.success(request,"Etudiant modifié avec succès!")
            return HttpResponseRedirect('/etudiant/listEtu')
    else:
            etudiant=tableEtudiant.objects.get(pk=id)
            fm= etudiantForm(instance=etudiant)
    return render(request,'etudiant/updateEtudiant.html',{'form':fm})


from django.shortcuts import render

# Create your views here.
