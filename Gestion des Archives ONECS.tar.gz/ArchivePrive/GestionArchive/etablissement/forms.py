from django.forms import SelectMultiple

from .models import tableEtablissement
from django import forms
from filiere.models import tableFiliere

#class filiereMany(forms.ModelMultipleChoiceField):


class etablissementForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(etablissementForm, self).__init__(*args, **kwargs)
        self.fields['nomEta'].label = "Nom de l'établissement"
        self.fields['arreteEta'].label = "Arreté de l'établissement"
        self.fields['dateArrete'].label = "Date de l'arreté"
        self.fields['filiere'].label="Liste des formations autorisées"
        self.fields['lmd'].label = "Système LMD"
        self.fields['btsNat'].label = "BTS National exigé"
        self.fields['cycle'].label = "Cycle de formation autorisé"
        self.fields['imgArrete'].label = "Pièce jointe de l'arreté"

    filiere= forms.ModelMultipleChoiceField(queryset=tableFiliere.objects.all(),
                                            widget=forms.SelectMultiple(attrs={'class': 'form-control', }))
    class Meta:
        model= tableEtablissement
        fields= ['nomEta','arreteEta','dateArrete','filiere','lmd','btsNat','cycle','imgArrete']

        widgets={
            'nomEta':forms.TextInput(attrs={'class':'form-control','placeholder':'Université EmiKoussi'}),
            'arreteEta':forms.TextInput(attrs={'class':'form-control','placeholder':'105/PR/MESRS/DG/'}),
            'dateArrete':forms.DateInput(attrs={'class':'form-control','placeholder':'04/20/2016'}),

            'lmd':forms.Select(attrs={'class':'form-control'}),
            'btsNat': forms.Select(attrs={'class': 'form-control'}),
            'cycle': forms.Select(attrs={'class': 'form-control'}),
            'imgArrete':forms.FileInput(attrs={'class':'form-control'}),
        }