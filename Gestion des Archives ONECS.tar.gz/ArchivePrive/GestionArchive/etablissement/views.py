from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from .forms import etablissementForm
from .models import tableEtablissement
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render


# Create your views here.
@login_required
def ajout_etablissement(request):
    if request.method == 'POST':
        fm = etablissementForm(request.POST, request.FILES)
        if fm.is_valid():
            reg= fm.save()
            filiere= request.POST.get('filiere')
            reg.filiere.add(filiere)
            reg.save()
            messages.success(request,'Etablissement ajouté avec succès')

            fm = etablissementForm()

    else:
        fm = etablissementForm()
    return render(request, 'etablissement/addEtablissement.html', {'navbar': 'addEta', 'form': fm})

@login_required
def list_etablissement(request):
    eta= tableEtablissement.objects.all()
    return render(request, 'etablissement/listEtablissement.html', {'navbar': 'listEta','etab':eta})

@login_required
def delete_etablissement(request, id):
    if request.method=='POST':
        etab= tableEtablissement.objects.get(pk=id)
        etab.delete()
        messages.success(request,'Etablissement supprimé avec succès!')
        return HttpResponseRedirect('/etablissement/listEtab')
@login_required
def update_etablissement(request,id):
    if request.method=='POST':
        etab= tableEtablissement.objects.get(pk=id)
        fm= etablissementForm(request.POST,request.FILES,instance=etab)
        if fm.is_valid():
            fm.save()
            messages.success(request,'Etablissement modifié avec succès!')
            return HttpResponseRedirect('/etablissement/listEtab')
    else:
        etab= tableEtablissement.objects.get(pk=id)
        fm= etablissementForm(instance=etab)
        return render(request,'etablissement/updateEtablissement.html',{'form':fm})


# Create your views here.
