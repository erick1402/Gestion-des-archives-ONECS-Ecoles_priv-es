from django.urls import path
from etablissement import views

urlpatterns=[
    path('addEtab/',views.ajout_etablissement,name='addEtab'),
    path('listEtab/',views.list_etablissement,name='listEtab'),
    path('delEta/<int:id>',views.delete_etablissement,name='delEta'),
    path('<int:id>',views.update_etablissement,name='updateEta')
]