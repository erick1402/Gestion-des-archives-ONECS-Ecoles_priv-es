from django.db import models
from django.db.models import ForeignKey
from filiere.models import tableFiliere

valeur_choix=[
    ('Oui','Oui'),
    ('Non','Non')
]
valeur_cycle=[
    ('Licence','Licence'),
    ('Master','Master'),
    ('Doctorat','Doctorat')
]


# Create your models here.
class tableEtablissement(models.Model):
    nomEta= models.CharField(max_length=300)
    arreteEta= models.CharField(max_length=500)
    dateArrete=models.DateField(null=True)
    filiere = models.ManyToManyField(tableFiliere)
    lmd= models.CharField(max_length=100,choices=valeur_choix,default='Oui')
    btsNat= models.CharField(max_length=100,choices=valeur_choix,default='Oui')
    cycle= models.CharField(max_length=100,choices=valeur_cycle,default='Licence')
    imgArrete= models.FileField(upload_to='documents',null=True, blank=True)
    dateEnreg= models.DateField(auto_now=True)
    def __str__(self):
        return self.nomEta



